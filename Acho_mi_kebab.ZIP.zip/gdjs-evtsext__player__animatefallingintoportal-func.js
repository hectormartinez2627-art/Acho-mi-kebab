
if (typeof gdjs.evtsExt__Player__AnimateFallingIntoPortal !== "undefined") {
  gdjs.evtsExt__Player__AnimateFallingIntoPortal.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__Player__AnimateFallingIntoPortal = {};
gdjs.evtsExt__Player__AnimateFallingIntoPortal.idToCallbackMap = new Map();
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1= [];
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects2= [];
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects1= [];
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects2= [];


gdjs.evtsExt__Player__AnimateFallingIntoPortal.asyncCallback19742324 = function (runtimeScene, eventsFunctionContext, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(eventsFunctionContext.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects2);

{for(var i = 0, len = gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Tween")).addObjectScaleTween2("ShrinkIntoPortal", 0.01, 0.01, "easeInSine", 1, true, true);
}
}
eventsFunctionContext.localVariables.length = 0;
}
gdjs.evtsExt__Player__AnimateFallingIntoPortal.idToCallbackMap.set(19742324, gdjs.evtsExt__Player__AnimateFallingIntoPortal.asyncCallback19742324);
gdjs.evtsExt__Player__AnimateFallingIntoPortal.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(eventsFunctionContext.localVariables);
for (const obj of gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.75), (runtimeScene) => (gdjs.evtsExt__Player__AnimateFallingIntoPortal.asyncCallback19742324(runtimeScene, eventsFunctionContext, asyncObjectsList)), 19742324, asyncObjectsList);
}
}

}


};gdjs.evtsExt__Player__AnimateFallingIntoPortal.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("Player"), gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Portal"), gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects1);
{for(var i = 0, len = gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Tween")).addObjectPositionTween2("MoveIntoPortal", (( gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects1.length === 0 ) ? 0 :gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects1[0].getCenterXInScene()) + (gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1[i].getWidth()) / 2, (( gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects1.length === 0 ) ? 0 :gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects1[0].getCenterYInScene()), "linear", 1, false);
}
}
{for(var i = 0, len = gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Tween")).addObjectAngleTween2("RotateIntoPortal", 360, "linear", 1, false);
}
}

{ //Subevents
gdjs.evtsExt__Player__AnimateFallingIntoPortal.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__Player__AnimateFallingIntoPortal.func = function(runtimeScene, Player, Tween, Portal, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
"Player": Player
, "Portal": Portal
},
  _objectArraysMap: {
"Player": gdjs.objectsListsToArray(Player)
, "Portal": gdjs.objectsListsToArray(Portal)
},
  _behaviorNamesMap: {
"Tween": Tween
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("Player"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("Player"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1.length = 0;
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects2.length = 0;
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects1.length = 0;
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects2.length = 0;

gdjs.evtsExt__Player__AnimateFallingIntoPortal.eventsList1(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects1.length = 0;
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPlayerObjects2.length = 0;
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects1.length = 0;
gdjs.evtsExt__Player__AnimateFallingIntoPortal.GDPortalObjects2.length = 0;


return;
}

gdjs.evtsExt__Player__AnimateFallingIntoPortal.registeredGdjsCallbacks = [];